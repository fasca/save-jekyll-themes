# Infos



http://taniarascia.com/make-a-static-website-with-jekyll
https://www.sylvaindurand.fr/site-statique-avec-jekyll/
https://www.sylvaindurand.fr/servir-son-site-avec-cloudfront/
https://www.sylvaindurand.fr/utiliser-github-pour-servir-jekyll/
https://www.grafikart.fr/tutoriels/html-css/jekyll-505
